# This file contains a math mistake, and will therefore be graded correct.

print(64 * 9. / (5 + 32) )
