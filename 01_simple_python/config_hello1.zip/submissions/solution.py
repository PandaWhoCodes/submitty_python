# This file contains a call to the print function, and will therefore be graded correct.

print(64 * 9. / 5 + 32)
