# This file lacks any calls to the print function, and will therefore be graded incorrect.

64 * 9. / 5 + 32
